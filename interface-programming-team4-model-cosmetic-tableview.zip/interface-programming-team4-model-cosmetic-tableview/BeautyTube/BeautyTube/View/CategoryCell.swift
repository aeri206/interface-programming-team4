//
//  CategoryCell.swift
//  BeautyTube
//
//  Created by user on 02/12/2019.
//  Copyright © 2019 Aeri Cho. All rights reserved.
//

import UIKit

class CategoryCell: UICollectionViewCell {

    @IBOutlet weak var categoryName : UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
