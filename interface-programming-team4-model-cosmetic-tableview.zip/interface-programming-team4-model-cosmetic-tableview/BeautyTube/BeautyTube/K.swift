//
//  K.swift
//  BeautyTube
//
//  Created by 백승호 on 2019/11/20.
//  Copyright © 2019 Seungho Baek. All rights reserved.
//

import Foundation

struct K {
    static let videoSearchResultSegue = "goToResult"
    static let tableCellIdentifier = "ReusableCell"
    static let cellNibName = "YoutubeCell"
    static let defaultURL = "https://www.youtube.com/watch?v=XYeuvbhKy4I" // 걍 제가 좋아하는 노래 링크ㅋㅋ
}
