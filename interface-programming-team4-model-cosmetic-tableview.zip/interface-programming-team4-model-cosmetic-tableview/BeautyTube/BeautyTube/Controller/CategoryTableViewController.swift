//
//  CategoryTableViewController.swift
//  BeautyTube
//
//  Created by 박민주 on 06/12/2019.
//  Copyright © 2019 Seungho Baek. All rights reserved.
//

import UIKit

struct cellData {
    var opened = Bool()
    var title = String()
    var sectionData = [String]()
}

class CategoryTableViewController: UITableViewController{
    
    var tableViewData = [cellData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableViewData = [cellData(opened: false, title: "스킨케어", sectionData: ["토너/필링패드","스킨", "에센스", "크림", "페이스오일", "로션", "메이크업픽서", "미스트"]),
                         cellData(opened: false, title: "클렌징", sectionData: ["클렌징폼", "클렌징오일", "클렌징밀크", "클렌징크림", "클렌징워터", "클렌징젤", "스크럽/필링", "포인트리무버", "클렌징티슈", "클렌징비누"]),
                         cellData(opened: false, title: "베이스메이크업", sectionData: ["메이크업베이스", "톤업크림", "베이스프라이머", "포인트프라이머", "파운데이션", "비비크림", "씨씨크림", "쿠션타입", "컨실러"]),
                         cellData(opened: false, title: "색조메이크업", sectionData: ["립스틱", "립글로스/락커", "립틴트", "립밤", "립라이너", "아이라이너-펜슬&젤", "아이라이너-리퀴드", "마스카라", "픽서/영양제", "아이섀도우", "아이브로우-펜슬", "아이브로우-파우더", "아이브로우-마스카라&리퀴드", "하이라이터", "쉐딩", "블러셔"]),
                         cellData(opened: false, title: "마스크/팩", sectionData: ["마스크시트", "수면팩", "워시오프", "필오프", "수딩젤/팩", "코팩"]),
                         cellData(opened: false, title: "선케어", sectionData: ["선블록", "선스프레이", "선스틱", "선쿠션", "태닝"]),
                         cellData(opened: false, title: "기능성화장품", sectionData: ["링클케어", "트러블케어", "화이트닝케어", "모공케어", "아이케어", "넥케어"]),
                         cellData(opened: false, title: "바디/핸드/풋", sectionData: ["바디워시", "바디스크럽", "바디로션", "바디크림", "바디오일", "바디미스트", "바디에센스", "바디밤/파우더", "핸드케어", "풋케어", "데오도란트", "목욕비누", "입욕제", "아로마테라피"]),
                         cellData(opened: false, title: "헤어", sectionData: ["샴푸", "린스/컨디셔너", "트리트먼트/팩", "헤어소품", "헤어에센스", "헤어스타일링", "염색제/퍼머제", "헤어기기"]),
                         cellData(opened: false, title: "네일", sectionData: ["네일컬러", "베이스/탑코트/퀵드라이", "네일아트/소품", "네일영양", "네일리무버"]),
                         cellData(opened: false, title: "여성용품", sectionData: ["소형", "중형", "대형", "오버나이트", "팬티라이너", "체내형", "청결제"]),
                         cellData(opened: false, title: "미용렌즈", sectionData: ["컬러렌즈", "렌즈관리용품", "투명렌즈"]),
                         cellData(opened: false, title: "향수", sectionData: ["여성향수", "남성향수", "방향제", "향초", "디퓨저"]),
                         cellData(opened: false, title: "기타제품", sectionData: ["브러쉬", "스펀지/퍼프", "뷰러", "페이스소품", "아이소품"]),
                         cellData(opened: false, title: "베이비&맘", sectionData: ["베이비스킨케어", "베이비바디", "베이비클렌저/샴푸", "베이비선케어", "키즈제품", "맘케어"]),
                         cellData(opened: false, title: "바디라인", sectionData: ["바디슬리밍", "제모제/용품", "건강/다이어트식품"]),
                         cellData(opened: false, title: "남성화장품", sectionData: ["스킨", "로션", "에센스", "크림", "클렌징", "스크럽/필링", "쉐이빙", "애프터쉐이브", "마스크/팩", "메이크업", "선케어", "헤어/바디", "헤어스타일링"])
        ]
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return tableViewData.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if tableViewData[section].opened == true {
            return tableViewData[section].sectionData.count + 1
        } else {
            return 1
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {return UITableViewCell()}
            cell.textLabel?.text = tableViewData[indexPath.section].title
            return cell
        } else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {return UITableViewCell()}
            cell.textLabel?.text = tableViewData[indexPath.section].sectionData[indexPath.row - 1]
            return cell
            
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            if tableViewData[indexPath.section].opened == true {
                tableViewData[indexPath.section].opened = false
                let sections = IndexSet.init(integer: indexPath.section)
                tableView.reloadSections(sections, with: .none)
            } else {
                tableViewData[indexPath.section].opened = true
                let sections = IndexSet.init(integer: indexPath.section)
                tableView.reloadSections(sections, with: .none)
            }
//        } else {
//        Youtube API 불러오기
        }
    }
}
